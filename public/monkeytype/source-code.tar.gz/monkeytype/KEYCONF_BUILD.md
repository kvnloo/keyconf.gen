# Keyconf guest build of Monkeytype

Upstream: https://github.com/monkeytypegame/monkeytype
Revision: 91bd24bb8513785c7364cbea29296ff7adafac41 (26.32.0)
Modified by Keyconf on 2026-09-05. This is an independent guest integration, not an official Monkeytype service.

Download and extract source-code.tar.gz, source-languages.tar.xz and source-assets.tar.gz into the same directory. Each archive starts with monkeytype/. Together they contain the complete corresponding source and static assets, including the pinned dependency lockfile. Run inside monkeytype/:

```
# Requires Node 24 and pnpm 11.21.0
pnpm --filter @monkeytype/frontend... install --frozen-lockfile
pnpm exec turbo run build --filter='@monkeytype/frontend^...'
RECAPTCHA_SITE_KEY='' BACKEND_URL='/monkeytype/guest-api' pnpm --filter @monkeytype/frontend exec vite build
```

Serve frontend/dist/ at a directory URL with index.html. Remove sw.js, workbox-*.js and manifest.json; this integration does not register a service worker. It works independently, or in a same-origin iframe. Optional postMessage events are defined in frontend/src/ts/keyconf-embed.ts. The embedding app must check the sending frame and origin.

Guest modifications: no Firebase initialization or backend calls; local server feature configuration; no analytics, ads, cookie prompt, reCAPTCHA or service worker; namespaced device settings; relative assets and internal routing; compact theme and typography; accessible decorative icons; keypress bridge. The original typing, scoring, test modes, restart, words, quotes and results implementation remains upstream.

Test completion cancels queued test UI animation frames before the result view removes the words. This prevents a delayed active-word update from accessing a completed test's removed DOM; live-test invariant checks remain enabled.

Monkeytype is GNU GPL version 3. See LICENSE. Original third-party assets retain their licenses and credits.
