import {
  clearActiveTags,
  toggleTagActive,
  __nonReactive,
} from "../../collections/tags";
import { Config } from "../../config/store";
import * as PaceCaret from "../../test/pace-caret";
import { isAuthenticated } from "../../states/core";
import { Command, CommandsSubgroup } from "../types";
import { showAddTagModal } from "../../components/modals/AddTagModal";

const subgroup: CommandsSubgroup = {
  title: "Tags...",
  list: [],
  beforeList: (): void => {
    update();
  },
};

const commands: Command[] = [
  {
    id: "changeTags",
    display: "Tags...",
    icon: "fa-tag",
    subgroup,
    available: (): boolean => {
      return isAuthenticated();
    },
  },
];

function update(): void {
  const tags = __nonReactive.getTags();
  subgroup.list = [];

  if (tags.length > 0) {
    subgroup.list.push({
      id: "clearTags",
      display: `Clear tags`,
      icon: "fa-times",
      sticky: true,
      exec: async (): Promise<void> => {
        await clearActiveTags();
        if (
          Config.paceCaret === "average" ||
          Config.paceCaret === "tagPb" ||
          Config.paceCaret === "daily"
        ) {
          await PaceCaret.init();
        }
      },
    });

    for (const tag of tags) {
      subgroup.list.push({
        id: `toggleTag${tag._id}`,
        display: tag.name,
        sticky: true,
        active: () => {
          return __nonReactive.getTag(tag._id)?.active ?? false;
        },
        exec: async (): Promise<void> => {
          await toggleTagActive({ tagId: tag._id });

          if (
            Config.paceCaret === "average" ||
            Config.paceCaret === "tagPb" ||
            Config.paceCaret === "daily"
          ) {
            await PaceCaret.init();
          }
        },
      });
    }
  }
  subgroup.list.push({
    id: "createTag",
    display: "Create tag",
    icon: "fa-plus",
    shouldFocusTestUI: false,
    opensModal: true,
    exec: (): void => {
      showAddTagModal();
    },
  });
}

export default commands;
