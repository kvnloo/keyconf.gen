import { BASE_CONFIGURATION } from "../constants/keyconf-server-configuration";
export const configurationPromise = Promise.resolve(true);
export function get() { return BASE_CONFIGURATION; }
export async function sync() {}
