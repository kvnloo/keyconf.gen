import { ResultFilters, ResultFiltersKeys } from "@monkeytype/schemas/users";
import { useLiveQuery } from "@tanstack/solid-db";
import { Accessor, createMemo, JSXElement } from "solid-js";

import {
  buildResultsQuery,
  ResultsQueryState,
} from "../../../collections/results";
import { type TagItem, useTagsLiveQuery } from "../../../collections/tags";
import { getConfig } from "../../../config/store";
import { getFormatting, isAuthenticated } from "../../../states/core";
import { FaSolidIcon } from "../../../types/font-awesome";
import {
  capitalizeFirstLetter,
  replaceUnderscoresWithSpaces,
} from "../../../utils/strings";
import { get as getTypingSpeedUnit } from "../../../utils/typing-speed-units";
import AsyncContent from "../../common/AsyncContent";
import { Fa } from "../../common/Fa";
import { DailyActivityChart } from "./DailyActivityChart";
import { HistogramChart } from "./HistogramChart";
import { HistoryChart, HistoryChartClickEvent } from "./HistoryChart";

export function Charts(props: {
  filters: ResultFilters;
  queryState: Accessor<ResultsQueryState | undefined>;
  onHistoryChartClick?: (event: HistoryChartClickEvent) => void;
}): JSXElement {
  const beginAtZero = createMemo(() => getConfig.startGraphsAtZero);
  const typingSpeedUnit = createMemo(() =>
    getTypingSpeedUnit(getConfig.typingSpeedUnit),
  );
  const format = getFormatting;
  const tags = useTagsLiveQuery();

  const resultsQuery = useLiveQuery((q) => {
    if (!isAuthenticated()) return undefined;
    const state = props.queryState();
    if (state === undefined) return undefined;
    return q
      .from({ r: buildResultsQuery(state) })
      .orderBy(({ r }) => r.timestamp, "desc");
  });

  return (
    <AsyncContent collections={{ resultsQuery }}>
      {({ resultsQueryData }) => (
        <div class="flex flex-col gap-8">
          <div>
            <FilterSummary filters={props.filters} tags={tags()} />
            <HistoryChart
              results={resultsQueryData()}
              beginAtZero={beginAtZero()}
              typingSpeedUnit={typingSpeedUnit()}
              format={format()}
              onClick={(index) => props.onHistoryChartClick?.(index)}
            />
          </div>

          <HistogramChart
            results={resultsQueryData()}
            typingSpeedUnit={typingSpeedUnit()}
          />

          <DailyActivityChart
            queryState={props.queryState}
            beginAtZero={beginAtZero()}
            typingSpeedUnit={typingSpeedUnit()}
            format={format()}
          />
        </div>
      )}
    </AsyncContent>
  );
}

function FilterSummary(props: {
  filters: ResultFilters;
  tags: TagItem[];
}): JSXElement {
  const Item = <
    T extends ResultFiltersKeys,
    K extends keyof ResultFilters[T],
  >(options: {
    group: T;
    icon: FaSolidIcon;
    format?: (val: K) => string;
  }): JSXElement => {
    const values = createMemo(() =>
      isAllSet(props.filters[options.group])
        ? "all"
        : Object.entries(props.filters[options.group])
            .filter(([_, v]) => v)
            .map(([it]) => options.format?.(it as K) ?? it)
            .join(", "),
    );

    return (
      <span
        aria-label={capitalizeFirstLetter(options.group)}
        data-balloon-pos="up"
      >
        <Fa icon={options.icon} fixedWidth />
        {values()}
      </span>
    );
  };

  return (
    <div class="mt-4 mb-4 flex flex-wrap justify-center gap-4 text-sub [&>span>i]:mr-1">
      <Item
        group="date"
        icon="fa-calendar"
        format={replaceUnderscoresWithSpaces}
      />
      <Item group="mode" icon="fa-bars" />
      <Item group="time" icon="fa-clock" />
      <Item group="words" icon="fa-font" />
      <Item group="difficulty" icon="fa-star" />
      <Item group="punctuation" icon="fa-at" />
      <Item group="numbers" icon="fa-hashtag" />
      <Item group="language" icon="fa-globe-americas" />
      <Item
        group="funbox"
        icon="fa-gamepad"
        format={replaceUnderscoresWithSpaces}
      />
      <Item
        group="tags"
        icon="fa-tags"
        format={(tag) => props.tags.find((it) => it._id === tag)?.name ?? tag}
      />
    </div>
  );
}

function isAllSet(
  filter: Record<string | number | symbol, boolean | undefined>,
): boolean {
  return Object.values(filter).every((value) => value);
}
