import {
  AccessorFnColumnDef,
  AccessorKeyColumnDef,
  ColumnDef,
  createSolidTable,
  flexRender,
  getCoreRowModel,
  getSortedRowModel,
  SortingState,
} from "@tanstack/solid-table";
import {
  Accessor,
  createEffect,
  createMemo,
  createSignal,
  For,
  JSXElement,
  Match,
  Show,
  splitProps,
  Switch,
} from "solid-js";
import { z } from "zod";

import { useLocalStorage } from "../../../hooks/useLocalStorage";
import { cn } from "../../../utils/cn";
import { Fa } from "../../common/Fa";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "./Table";

const SortingStateSchema = z.array(
  z.object({
    desc: z.boolean(),
    id: z.string(),
  }),
);

// oxlint-disable-next-line typescript/no-explicit-any
export type DataTableColumnDef<TData, TValue = any> =
  | ColumnDef<TData, TValue>
  | AccessorFnColumnDef<TData, TValue>
  | AccessorKeyColumnDef<TData, TValue>;

export type DataTableProps<TData, TValue> = {
  id: string;
  columns: DataTableColumnDef<TData, TValue>[];
  data: TData[];
  fallback?: JSXElement;
  hideHeader?: true;
  rowSelection?: {
    getRowId: (row: TData) => string;
    class: string;
    activeRow: Accessor<string | null>;
  };
  class?: string;
  headerCellClass?: string;
  bodyCellClass?: string;
  onSortingChange?: (sorting: SortingState) => void;
  noDataRow?:
    | true
    | {
        content: JSXElement;
      };
};

// oxlint-disable-next-line typescript/no-explicit-any
export function DataTable<TData extends Object, TValue = any>(
  props: DataTableProps<TData, TValue>,
): JSXElement {
  const [sorting, setSorting] = useLocalStorage<SortingState>({
    //oxlint-disable-next-line solid/reactivity
    key: `${props.id}Sort`,
    schema: SortingStateSchema,
    fallback: [],
    //migrate old state from sorted-table
    migrate: (value: Record<string, unknown> | unknown[]) =>
      value !== null &&
      typeof value === "object" &&
      "property" in value &&
      "descending" in value
        ? [
            {
              id: value["property"] as string,
              desc: value["descending"] as boolean,
            },
          ]
        : [],
  });

  const [rowSelection, setRowSelection] = createSignal({});
  createEffect(() => {
    if (props.rowSelection?.activeRow === undefined) {
      setRowSelection({});
    } else {
      const activeId = props.rowSelection.activeRow();
      setRowSelection(activeId !== null ? { [activeId]: true } : {});
    }
  });

  // Ensure reactivity: always produce a fresh array reference
  const data = createMemo(() => props.data.map((it) => ({ ...it })));

  // Recreate the table instance whenever data or columns change
  const table = createMemo(() =>
    createSolidTable<TData>({
      data: data(),
      get columns() {
        return props.columns;
      },
      getCoreRowModel: getCoreRowModel(),
      onSortingChange: (it) => {
        setSorting(it);
        props.onSortingChange?.(sorting());
      },

      //oxlint-disable-next-line solid/reactivity
      ...(props.onSortingChange
        ? { manualSorting: true }
        : { getSortedRowModel: getSortedRowModel() }),
      enableRowSelection: () => props.rowSelection !== undefined,
      getRowId: (row, index) =>
        props.rowSelection !== undefined
          ? props.rowSelection.getRowId(row)
          : typeof (row as Record<string, unknown>)["_id"] === "string"
            ? ((row as Record<string, unknown>)["_id"] as string)
            : index.toString(),
      onRowSelectionChange: setRowSelection,

      state: {
        get sorting() {
          return sorting();
        },
        get rowSelection() {
          return rowSelection();
        },
      },
    }),
  );

  //create column visibility classes once, make them accessible via the column.id
  const columnVisibility = createMemo(() => {
    return Object.fromEntries(
      table()
        .getAllColumns()
        .map((it) => {
          const breakpoint =
            it.columnDef.meta?.breakpoint === "xxl"
              ? "2xl"
              : it.columnDef.meta?.breakpoint;
          const maxBreakpoint =
            it.columnDef.meta?.maxBreakpoint === "xxl"
              ? "2xl"
              : it.columnDef.meta?.maxBreakpoint;

          // 🚨 Tailwind does not generate CSS for dynamically constructed class names.
          const classes = {
            hidden: false,
            "xxs:table-cell": false,
            "xs:table-cell": false,
            "sm:table-cell": false,
            "md:table-cell": false,
            "lg:table-cell": false,
            "xl:table-cell": false,
            "2xl:table-cell": false,
            "xxs:hidden": false,
            "xs:hidden": false,
            "sm:hidden": false,
            "md:hidden": false,
            "lg:hidden": false,
            "xl:hidden": false,
            "2xl:hidden": false,
          };
          if (breakpoint !== undefined) {
            classes.hidden = true;
            classes[`${breakpoint}:table-cell`] = true;
          }
          if (maxBreakpoint !== undefined) {
            classes[`${maxBreakpoint}:hidden`] = true;
          }
          return [it.id, classes];
        }),
    );
  });

  return (
    <Show
      when={table().getRowModel().rows?.length || props.noDataRow !== undefined}
      fallback={props.fallback}
    >
      <Table id={props.id} class={props.class}>
        <Show when={!props.hideHeader}>
          <TableHeader>
            <For each={table().getHeaderGroups()}>
              {(headerGroup) => (
                <TableRow>
                  <For each={headerGroup.headers}>
                    {(header) => (
                      <Show
                        when={header.column.getCanSort()}
                        fallback={
                          <TableHead
                            colSpan={header.colSpan}
                            class={cn(
                              {
                                "text-left":
                                  (header.column.columnDef.meta?.align ??
                                    "left") === "left",
                                "text-center":
                                  header.column.columnDef.meta?.align ===
                                  "center",
                                "text-right":
                                  header.column.columnDef.meta?.align ===
                                  "right",
                              },
                              columnVisibility()[header.column.id],
                              props.headerCellClass,
                            )}
                            {...(header.column.columnDef.meta?.headerMeta ??
                              {})}
                          >
                            <Show when={!header.isPlaceholder}>
                              {flexRender(
                                header.column.columnDef.header,
                                header.getContext(),
                              )}
                            </Show>
                          </TableHead>
                        }
                      >
                        <TableHead
                          colSpan={header.colSpan}
                          aria-sort={
                            header.column.getIsSorted() === "asc"
                              ? "ascending"
                              : header.column.getIsSorted() === "desc"
                                ? "descending"
                                : "none"
                          }
                          class={cn(
                            "p-0",
                            columnVisibility()[header.column.id],
                          )}
                        >
                          <button
                            type="button"
                            role="button"
                            onClick={(e) => {
                              header.column.getToggleSortingHandler()?.(e);
                            }}
                            class={cn(
                              "m-0 box-border flex h-full w-full cursor-pointer items-start rounded-none border-0 bg-transparent p-2 font-normal whitespace-nowrap text-sub hover:bg-sub-alt",
                              {
                                "justify-start text-left":
                                  (header.column.columnDef.meta?.align ??
                                    "left") === "left",
                                "justify-center text-center":
                                  header.column.columnDef.meta?.align ===
                                  "center",
                                "justify-end text-right":
                                  header.column.columnDef.meta?.align ===
                                  "right",
                              },
                              props.headerCellClass,
                              header.column.columnDef.meta?.headerClass,
                            )}
                            {...(header.column.columnDef.meta?.headerMeta ??
                              {})}
                          >
                            <Show when={!header.isPlaceholder}>
                              {flexRender(
                                header.column.columnDef.header,
                                header.getContext(),
                              )}
                            </Show>

                            <Switch fallback={<i class="fa-fw"></i>}>
                              <Match
                                when={header.column.getIsSorted() === "asc"}
                              >
                                <Fa
                                  icon={"fa-sort-up"}
                                  fixedWidth
                                  aria-hidden="true"
                                />
                              </Match>
                              <Match
                                when={header.column.getIsSorted() === "desc"}
                              >
                                <Fa
                                  icon={"fa-sort-down"}
                                  fixedWidth
                                  aria-hidden="true"
                                />
                              </Match>
                            </Switch>
                          </button>
                        </TableHead>
                      </Show>
                    )}
                  </For>
                </TableRow>
              )}
            </For>
          </TableHeader>
        </Show>
        <TableBody>
          <For each={table().getRowModel().rows}>
            {(row) => (
              <TableRow
                {...{
                  "data-state": row.getIsSelected() ? "selected" : undefined,
                }}
                class={
                  row.getIsSelected() && props.rowSelection
                    ? props.rowSelection.class
                    : ""
                }
              >
                <For each={row.getVisibleCells()}>
                  {(cell) => {
                    const [cellClass, cellMeta] = splitProps(
                      typeof cell.column.columnDef.meta?.cellMeta === "function"
                        ? cell.column.columnDef.meta.cellMeta({
                            value: cell.getValue(),
                            row: cell.row.original,
                          })
                        : (cell.column.columnDef.meta?.cellMeta ?? {}),
                      ["class"],
                    );
                    return (
                      <TableCell
                        {...cellMeta}
                        class={cn(
                          "",
                          {
                            "text-left":
                              (cell.column.columnDef.meta?.align ?? "left") ===
                              "left",
                            "text-center":
                              cell.column.columnDef.meta?.align === "center",
                            "text-right":
                              cell.column.columnDef.meta?.align === "right",
                          },
                          columnVisibility()[cell.column.id],
                          props.bodyCellClass,
                          cellClass.class,
                        )}
                      >
                        {flexRender(
                          cell.column.columnDef.cell,
                          cell.getContext(),
                        )}
                      </TableCell>
                    );
                  }}
                </For>
              </TableRow>
            )}
          </For>
          <Show
            when={
              !table().getRowModel().rows?.length &&
              props.noDataRow !== undefined
            }
          >
            <TableRow>
              <TableCell
                colSpan={table().getAllColumns().length}
                class="text-center text-sub"
              >
                {props.noDataRow !== undefined &&
                  (props.noDataRow === true
                    ? "No data"
                    : props.noDataRow.content)}
              </TableCell>
            </TableRow>
          </Show>
        </TableBody>
      </Table>
    </Show>
  );
}
