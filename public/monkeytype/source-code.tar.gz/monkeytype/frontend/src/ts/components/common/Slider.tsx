import { createEffect, createSignal, JSXElement } from "solid-js";

type Props = {
  ref?: (el: HTMLInputElement) => void;
  value: number;
  min: number;
  max: number;
  step?: number;
  onChange?: (value: number) => void;
  onEveryChange?: (value: number) => void;
  text?: (value: number) => string | JSXElement;
};

export function Slider(props: Props): JSXElement {
  const [value, setValue] = createSignal(0);
  createEffect(() => setValue(props.value));

  const textToDisplay = () => {
    if (props.text) {
      return props.text(value());
    }
    return value();
  };

  return (
    <div class="grid grid-cols-[3ch_1fr] items-center gap-4">
      <div>{textToDisplay()}</div>
      <input
        ref={props.ref}
        type="range"
        min={props.min}
        max={props.max}
        value={value()}
        step={props.step}
        onInput={(e) => {
          const newValue = Number(e.target.value);
          setValue(newValue);
          props.onEveryChange?.(newValue);
        }}
        onChange={(e) => props.onChange?.(Number(e.target.value))}
      />
    </div>
  );
}
