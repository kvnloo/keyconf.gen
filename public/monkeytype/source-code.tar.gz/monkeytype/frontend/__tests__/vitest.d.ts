// oxlint-disable typescript/consistent-type-definitions
import type { Assertion, AsymmetricMatchersContaining } from "vitest";
import { TestActivityDay } from "../src/ts/elements/test-activity-calendar";

interface ActivityDayMatchers<R = TestActivityDay> {
  toBeDate: (date: string) => ActivityDayMatchers<R>;
  toHaveTests: (tests: number) => ActivityDayMatchers<R>;
  toHaveLevel: (level?: string | number) => ActivityDayMatchers<R>;
  toBeFiller: () => ActivityDayMatchers<R>;
}

/// <reference types="vitest" />
import "@testing-library/jest-dom";

declare module "vitest" {
  // oxlint-disable-next-line typescript/no-empty-object-type
  interface Assertion<T = any> extends ActivityDayMatchers<T> {}
  // oxlint-disable-next-line typescript/no-empty-object-type
  interface AsymmetricMatchersContaining extends ActivityDayMatchers {}
}

interface MatcherResult {
  pass: boolean;
  message: () => string;
  actual?: unknown;
  expected?: unknown;
}
