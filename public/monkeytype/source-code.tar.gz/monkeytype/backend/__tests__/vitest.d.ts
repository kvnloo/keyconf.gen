// oxlint-disable typescript/consistent-type-definitions
import type { Assertion, AsymmetricMatchersContaining } from "vitest";
import type { Test as SuperTest } from "supertest";
import MonkeyError from "../src/utils/error";

type ExpectedRateLimit = {
  /** max calls */
  max: number;
  /** window in milliseconds. Needs to be within 2500ms */
  windowMs: number;
};
interface RestRequestMatcher<R = Supertest> {
  toBeRateLimited: (
    expected: ExpectedRateLimit,
  ) => Promise<RestRequestMatcher<R>>;
}
interface ThrowMatcher {
  toMatchMonkeyError: (expected: {
    status: number;
    message: string;
  }) => MatcherResult;
}

declare module "vitest" {
  interface Assertion<T = any> extends RestRequestMatcher<T>, ThrowMatcher {}
  interface AsymmetricMatchersContaining
    extends RestRequestMatcher, ThrowMatcher {}
}

interface MatcherResult {
  pass: boolean;
  message: () => string;
  actual?: unknown;
  expected?: unknown;
}
